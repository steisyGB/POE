﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioPOE
{
    public class Estudiante
    {
        private string nombre;

        public string Nombre { get; set; }
    }
}
